
import App = require("./app");

var greeter = new App.Controller("Whatup");

greeter.greet();
